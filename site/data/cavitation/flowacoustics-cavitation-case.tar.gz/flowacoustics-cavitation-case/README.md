# Cavitating 2D WALE case setup

This package contains the exact 18 initial field, mesh and solver-dictionary files prepared for the separate `mrl2d_les_cavitation` calculation. It contains **no solved fields, acoustic prediction or completion certificate**. It is an OpenFOAM case-input handover, not a standalone OpenFOAM installation or the Python postprocessing application.

## Model and comparison

- OpenCFD OpenFOAM v2206, `interPhaseChangeDyMFoam`, Schnerr–Sauer phase change, WALE closure.
- Strict two-dimensional, one-layer empty-z mesh: 26,751 cells, 0.01 m numerical depth, circular farfield radius 0.6 m. Three elliptical blades retain the original prescribed orbit and pitch.
- Target duration 10 s; two MPI ranks. Initial timestep and configured nominal `maxDeltaT` are 6.25e-5 s; adaptive bulk-Courant target 0.5. Adjustable-runtime output alignment can increase a realized timestep above that nominal setting, so actual timestep extrema must be read from the solver log rather than inferred from the dictionary. The installed solver's `maxAlphaCo` is not an additional active limiter.
- Fully liquid initial field and inflow, 1 m/s freestream, zero gravity. Vapour develops through the phase-change equation, not a prescribed cloud.
- Nominal temperature 20 °C, without an energy equation. Farfield reference **3500 Pa absolute**: a reduced-pressure tunnel assumption, not atmospheric or ocean operation. The freestream pressure condition is mixed; it does not fix every boundary face to that value.
- Saturation pressure 2339.3 Pa and vapour density 0.017314 kg/m³ correspond to the NIST saturated-water table at 20 °C.[2]
- Liquid density 1000 kg/m³ and kinematic viscosity 1e-6 m²/s retain the single-phase baseline's modelling constants. Approximate vapour dynamic viscosity 1e-5 Pa·s gives the kinematic viscosity written in `transportProperties`; surface tension is assumed 0.0728 N/m.
- Schnerr–Sauer nuclei parameters n=1.6e13 m⁻³, dNuc=2e-6 m, Cc=Cv=1 are tutorial-based assumptions, not calibrated measurements of this rotor.

The comparison reference is the existing liquid-only `mrl2d_les_body`. Its native pressure is kinematic gauge pressure and converts to Pa by multiplying by 1000. The cavitation solver's `p` is already absolute Pa (`p=p_rgh` at zero gravity); its pressure relative to the farfield is `p-3500`. Never multiply the new pressure by density again. Different solvers, time schemes and wall-pressure treatment mean this is not an isolated, validated measurement of the cavitation effect.

## Running the setup

Install/source a compatible OpenCFD v2206 environment first. Run from a fresh extracted `mrl2d_les_cavitation` directory; do not overwrite or restart a previously executed case implicitly. The following are the native stages used by the local workflow:

```sh
checkMesh -allGeometry -allTopology -time 0
decomposePar
mpirun --bind-to none -np 2 interPhaseChangeDyMFoam -parallel
reconstructPar -noFunctionObjects
checkMesh -allGeometry -allTopology -time 10
```

Set `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1` and `MKL_NUM_THREADS=1` for the run. Allow substantial wall time and disk space: this is a native CFD calculation, not an instant browser demo. The packaged input files are byte-checked against the prepared case; this archive has not been independently re-solved in a different environment. Native process supervision, time limits and independent scientific acceptance are the operator's responsibility.

Output settings request 500 ASCII VTK planes at 0.02 s cadence and 50 positive full-volume states at 0.2 s cadence. Actual VTK arrays/time metadata are Float32 despite ASCII write precision 17. Keep native connectivity and clocks; omit exactly zero projected-area triangles only for display, without altering the raw export.

`postProcessing/phaseVolume/0/volFieldValue.dat` contains direct water and vapour volume integrals. The vapour area per numerical span is `volIntegrate(alpha.vapour)/0.01`. The sum of the two phase integrals checks geometric volume; it is **not a source-aware mixture mass-conservation certificate**. The separate extrema file supplies native-cell statistics; cutting-plane point extrema are a different support.

## Interpretation limits

This is a reduced-pressure, strict-2D WALE-model teaching calculation. It is not resolved 3D turbulence, individual-bubble dynamics, compressible collapse shocks or cavitation-noise prediction. No acoustic recorder is loaded. Mesh/time-step convergence, calibrated nuclei parameters, experimental validation and source-aware mixture mass/phase-flux conservation remain unestablished. A successful solver exit alone is not physical validation or complete output acceptance.

`SHA256SUMS` checks the input files and this guide. No solver binaries, papers, private audits, credentials, native execution receipts or raw solved CFD fields are redistributed. No additional project-wide licence permission is asserted; OpenFOAM remains an external dependency under its own licence.

## Sources

[2] https://www.nist.gov/document/nistir5078-tab1pdf
